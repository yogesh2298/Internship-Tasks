<?php 
$servername = 'localhost';
$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$message = $_POST["message"];

$conn = new mysqli('localhost','root',"",'mydatabase');
if($conn->connect_error)
     {
     	die("Connection Failed:".$conn->connect_error);
     }
     else
     {
     	$x = $conn->prepare("insert into form(name,email,message,phone)values(?,?,?,?)");
     	$x->bind_param("ssss",$name,$email,$message,$phone);
     	$x->execute();
     	echo"Data is Entered.";
     	$x->close();
     	$conn->close();
     }

?>